x=input('enter a number: ')
ValueError
print('enter a whole number')
y=input('enter a second number: ')
ValueError
print('enter a whole number')

